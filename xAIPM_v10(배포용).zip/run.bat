@echo off
cd /d "%~dp0"
streamlit run xAIPM.py
pause